package com.company;

public class Main {
    public static void main(String[] args){

        //int numeroWhile = 1; //asigno el valor a la variable
       //while (numeroWhile <10){
          //numeroWhile++;
          // System.out.println(numeroWhile);

        //int ejemplo2 = 20; //asigno el valor a la variable
        //do {
         //   ejemplo2--;
          //  System.out.println(ejemplo2);
       // } while(ejemplo2 ==20);

        //int numeroFor = 0;
       // for (; numeroFor <=3; numeroFor = numeroFor +1){
       //     System.out.println(numeroFor);
       // }

        var estaciondelmes = "OTOÑO"; //asigno una estacion a la variable
        switch (estaciondelmes){
            case "VERANO": //compruebo si es el caso de que estemos en VERANO
                System.out.println("ESTAMOS EN VERANO"); //si estamos en verano lo muestro por consola
                break; //rompo la ejecución del resto del switch
            case "PRIMAVERA": //""
                System.out.println("ESTAMOS EN PRIMAVERA");
                break;
            case "OTOÑO":
                System.out.println("ESTAMOS EN OTOÑO");
                break;
            case "INVIERNO":
                System.out.println("ESTAMOS EN INVIERNO");
                break;
            default:
                System.out.println("NO SÉ EN QUÉ ESTACIÓN ESTAMOS");
        }
    }

}
